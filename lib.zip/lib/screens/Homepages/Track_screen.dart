import 'package:flutter/material.dart';
import 'package:my_new_sustain_app/screens/Homepages/GreenTips_screen.dart';
import 'package:my_new_sustain_app/screens/Homepages/Profile_Screen.dart';
import 'package:intl/intl.dart';

// Assuming this has the GreenTip class

class TrackScreen extends StatelessWidget {
  final List<GreenTip> selectedTips;

  TrackScreen({required this.selectedTips});

  @override
  Widget build(BuildContext context) {
    int completedCount = selectedTips.where((tip) => tip.isSelected).length;
    double progress =
        selectedTips.isNotEmpty ? completedCount / selectedTips.length : 0.0;

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text(
          'Track Today\'s Green Wins',
          style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.white,
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Date Tag
            Container(
              padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 12),
              decoration: BoxDecoration(
                color: Colors.yellow.shade600,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(
                '🌞 Today: ${DateFormat('d MMMM').format(DateTime.now())}',
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
            ),
            const SizedBox(height: 16),

            // Progress bar
            ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: LinearProgressIndicator(
                value: progress,
                minHeight: 10,
                backgroundColor: Colors.grey.shade300,
                valueColor: AlwaysStoppedAnimation<Color>(Colors.green),
              ),
            ),
            const SizedBox(height: 24),

            const Text(
              'Tips Completed:',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
            ),
            const SizedBox(height: 12),

            // List of tips with checkboxes
            Expanded(
              child: ListView.builder(
                itemCount: selectedTips.length,
                itemBuilder: (context, index) {
                  final tip = selectedTips[index];
                  return CheckboxListTile(
                    title: Text(tip.title),
                    value: tip.isSelected,
                    onChanged: (_) {}, // Disabled here – use setState if needed
                    controlAffinity: ListTileControlAffinity.leading,
                  );
                },
              ),
            ),

            // Progress note
            Text(
              "You're ${(progress * 100).round()}% there — small steps, big impact! 🌍",
              style: const TextStyle(fontWeight: FontWeight.w600),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const [
          BottomNavigationBarItem(
              icon: Icon(Icons.grid_view_rounded), label: ''),
          BottomNavigationBarItem(icon: Icon(Icons.person_outline), label: ''),
        ],
        currentIndex: 0,
        onTap: (index) {
          if (index == 1) {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => ProfileScreen(
                    selectedTips: selectedTips), // Replace 'tips' if needed
              ),
            );
          }
          // If you want index 0 (main screen), you can also handle it here if needed
        },
      ),
    );
  }
}
